const Discord = require('discord.js');
const client = new Discord.Client();
const auth = require('./auth.json');

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

client.on('message', msg => {
  if (msg.content === '?skybot') {
    msg.reply('The SkyBot Model 200-S is an experimental development design created by SkyPotato.');
  }
});

client.on('message', msg => {
  if (msg.content === 'hi') {
    msg.reply('Why, hello there! Glad you stopped by!');
  }
});

client.on('message', msg => {
  if (msg.content === 'Hi') {
    msg.reply('Why, hello there! Glad you stopped by!');
  }
});

client.on('message', msg => {
  if (msg.content === '?floridaman') {
    msg.reply('dont you think that @Sajeel#2417 is absoulutely terrible? Because I do.');
  }
});

client.on('message', msg => {
  if (msg.content === 'fricking normies') {
    msg.reply('REEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE');
  }
});

client.on('message', msg => {
  if (msg.content === 'ping') {
    msg.reply('pong');
  }
});

client.on('message', msg => {
  if (msg.content === '?sbhelp') {
    msg.reply('the full list of commands can be found at https://github.com/bluespeedmouse/skybotv2/blob/master/README.md');
  }
});

client.login(auth.token);